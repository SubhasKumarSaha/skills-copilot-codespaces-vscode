export interface Report {
  id: string;
  title: string;
  description: string;
  location: {
    latitude: number;
    longitude: number;
    address?: string;
  };
  status: 'pending' | 'in-progress' | 'completed';
  createdAt: string;
  updatedAt: string;
  userId: string;
  imageUrl: string;
  cleanupImageUrl?: string;
  assignedTo?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'citizen' | 'authority';
  createdAt: string;
}

export interface GeoLocation {
  latitude: number;
  longitude: number;
  error?: string;
}

export interface ReportFormData {
  title: string;
  description: string;
  imageUrl: string;
  location: {
    latitude: number;
    longitude: number;
    address?: string;
  };
}

export interface AuthorityFormData {
  status: 'in-progress' | 'completed';
  cleanupImageUrl?: string;
  notes?: string;
}
