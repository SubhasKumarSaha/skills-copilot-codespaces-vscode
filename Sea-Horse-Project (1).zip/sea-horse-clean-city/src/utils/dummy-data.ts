import { Report, User } from '@/types';

// Dummy users for testing
export const dummyUsers: User[] = [
  {
    id: '1',
    name: 'John Citizen',
    email: 'john@example.com',
    role: 'citizen',
    createdAt: new Date(2023, 5, 15).toISOString(),
  },
  {
    id: '2',
    name: 'Municipal Authority',
    email: 'authority@citygovt.org',
    role: 'authority',
    createdAt: new Date(2023, 1, 10).toISOString(),
  },
];

// Dummy reports for testing
export const dummyReports: Report[] = [
  {
    id: '1',
    title: 'Plastic Waste on Beach',
    description: 'Large amount of plastic debris washed up on the shore. Needs immediate cleanup.',
    location: {
      latitude: 19.076,
      longitude: 72.8777,
      address: 'Dadar Beach, Mumbai',
    },
    status: 'pending',
    userId: '1',
    createdAt: new Date(2024, 2, 15).toISOString(),
    updatedAt: new Date(2024, 2, 15).toISOString(),
    imageUrl: '/images/pollution1.jpg',
  },
  {
    id: '2',
    title: 'Industrial Waste Dumping',
    description: 'Chemical waste being dumped in the river. Strong smell and water discoloration.',
    location: {
      latitude: 19.096,
      longitude: 72.8976,
      address: 'Mithi River, BKC, Mumbai',
    },
    status: 'in-progress',
    userId: '1',
    assignedTo: '2',
    createdAt: new Date(2024, 2, 10).toISOString(),
    updatedAt: new Date(2024, 2, 18).toISOString(),
    imageUrl: '/images/pollution2.jpg',
  },
  {
    id: '3',
    title: 'Garbage Pile on Street',
    description: 'Uncollected garbage piling up on street corner for over a week.',
    location: {
      latitude: 19.0596,
      longitude: 72.8295,
      address: 'Andheri West, Mumbai',
    },
    status: 'completed',
    userId: '1',
    assignedTo: '2',
    createdAt: new Date(2024, 1, 25).toISOString(),
    updatedAt: new Date(2024, 2, 5).toISOString(),
    imageUrl: '/images/pollution1.jpg',
    cleanupImageUrl: '/images/cleanup1.jpg',
  },
  {
    id: '4',
    title: 'Oil Spill Near Harbor',
    description: 'Small oil spill noticed near the harbor affecting local marine life.',
    location: {
      latitude: 18.9217,
      longitude: 72.8332,
      address: 'Gateway of India, Mumbai',
    },
    status: 'completed',
    userId: '1',
    assignedTo: '2',
    createdAt: new Date(2024, 1, 18).toISOString(),
    updatedAt: new Date(2024, 2, 1).toISOString(),
    imageUrl: '/images/pollution2.jpg',
    cleanupImageUrl: '/images/cleanup2.jpg',
  },
];
