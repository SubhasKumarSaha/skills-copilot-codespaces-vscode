import { GeoLocation } from "@/types";

// Function to get current geolocation using the browser's Geolocation API
export const getCurrentLocation = (): Promise<GeoLocation> => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject({
        latitude: 0,
        longitude: 0,
        error: "Geolocation is not supported by your browser"
      });
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        });
      },
      (error) => {
        // Fallback to default location (Mumbai, India)
        resolve({
          latitude: 19.076,
          longitude: 72.8777,
          error: `Unable to retrieve your location: ${error.message}`
        });
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0
      }
    );
  });
};

// Function to format address using latitude and longitude
// In a real app, you might use a geocoding service like Google Maps API
export const getAddressFromCoords = async (
  latitude: number,
  longitude: number
): Promise<string | undefined> => {
  // This is just a dummy implementation
  // In a real application, you would use a geocoding service
  try {
    // Simulating a delay for a real API call
    await new Promise((resolve) => setTimeout(resolve, 500));

    // Return a dummy address based on the coordinates
    return `Location at ${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
  } catch (error) {
    console.error("Error getting address:", error);
    return undefined;
  }
};
