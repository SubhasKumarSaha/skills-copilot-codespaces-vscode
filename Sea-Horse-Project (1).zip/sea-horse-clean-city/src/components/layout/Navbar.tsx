"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Menu, LogOut, User } from "lucide-react";

export function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userRole, setUserRole] = useState<'citizen' | 'authority' | null>('citizen');

  // In a real app, this would be handled by authentication
  const toggleUserRole = () => {
    setUserRole(prev => prev === 'citizen' ? 'authority' : 'citizen');
  };

  const logout = () => {
    // In a real app, this would handle logout logic
    console.log("Logging out...");
  };

  return (
    <nav className="fixed w-full top-0 z-50 bg-background border-b border-border/40 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center space-x-2">
            <Image
              src="/images/green-seahorse-logo.jpg"
              alt="Sea Horse Logo"
              width={40}
              height={40}
              className="rounded-md"
            />
            <span className="font-bold text-xl hidden md:inline-block">Sea Horse</span>
          </Link>
        </div>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-4">
          <Link href="/dashboard" className="text-sm font-medium transition-colors hover:text-primary">
            Dashboard
          </Link>
          <Link href="/reports" className="text-sm font-medium transition-colors hover:text-primary">
            Reports
          </Link>
          <Link href="/upload" className="text-sm font-medium transition-colors hover:text-primary">
            Report Issue
          </Link>
          <Button variant="outline" onClick={toggleUserRole} className="text-xs">
            {userRole === 'citizen' ? 'Switch to Authority' : 'Switch to Citizen'}
          </Button>
          <Avatar>
            <AvatarImage src="" />
            <AvatarFallback className="bg-primary text-primary-foreground">
              {userRole === 'citizen' ? 'JC' : 'MA'}
            </AvatarFallback>
          </Avatar>
        </div>

        {/* Mobile Menu Button */}
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          <Menu className="h-5 w-5" />
        </Button>
      </div>

      {/* Mobile Navigation Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-border/40 py-4 px-8 bg-background">
          <div className="flex flex-col space-y-4">
            <Link
              href="/dashboard"
              className="text-sm font-medium transition-colors hover:text-primary"
              onClick={() => setMobileMenuOpen(false)}
            >
              Dashboard
            </Link>
            <Link
              href="/reports"
              className="text-sm font-medium transition-colors hover:text-primary"
              onClick={() => setMobileMenuOpen(false)}
            >
              Reports
            </Link>
            <Link
              href="/upload"
              className="text-sm font-medium transition-colors hover:text-primary"
              onClick={() => setMobileMenuOpen(false)}
            >
              Report Issue
            </Link>
            <div className="pt-4 border-t border-border/40">
              <div className="flex items-center space-x-2 mb-2">
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                    {userRole === 'citizen' ? 'JC' : 'MA'}
                  </AvatarFallback>
                </Avatar>
                <span className="text-sm font-medium">
                  {userRole === 'citizen' ? 'John Citizen' : 'Municipal Authority'}
                </span>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start text-xs mb-2"
                onClick={toggleUserRole}
              >
                <User className="mr-2 h-4 w-4" />
                {userRole === 'citizen' ? 'Switch to Authority' : 'Switch to Citizen'}
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start text-xs"
                onClick={logout}
              >
                <LogOut className="mr-2 h-4 w-4" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
