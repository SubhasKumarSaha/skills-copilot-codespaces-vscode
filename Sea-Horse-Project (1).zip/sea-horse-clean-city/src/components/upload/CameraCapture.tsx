"use client";

import React, { useRef, useState, useCallback } from 'react';
import Webcam from 'react-webcam';
import { Button } from '@/components/ui/button';
import { Camera, RefreshCw, Check } from 'lucide-react';

interface CameraCaptureProps {
  onCapture: (imageSrc: string) => void;
}

export function CameraCapture({ onCapture }: CameraCaptureProps) {
  const webcamRef = useRef<Webcam>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);

  const activateCamera = () => {
    setIsCameraActive(true);
  };

  const capture = useCallback(() => {
    if (webcamRef.current) {
      const imageSrc = webcamRef.current.getScreenshot();
      if (imageSrc) {
        setCapturedImage(imageSrc);
      }
    }
  }, [webcamRef]);

  const retake = () => {
    setCapturedImage(null);
  };

  const confirmImage = () => {
    if (capturedImage) {
      onCapture(capturedImage);
      setCapturedImage(null);
      setIsCameraActive(false);
    }
  };

  const videoConstraints = {
    width: 720,
    height: 480,
    facingMode: "environment"
  };

  if (!isCameraActive && !capturedImage) {
    return (
      <div className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-primary/20 rounded-lg bg-primary/5 h-64">
        <Camera className="h-10 w-10 text-primary/40 mb-4" />
        <p className="text-center text-muted-foreground mb-4">
          Capture a photo of the pollution using your device camera
        </p>
        <Button onClick={activateCamera}>
          <Camera className="mr-2 h-4 w-4" />
          Activate Camera
        </Button>
      </div>
    );
  }

  return (
    <div className="relative overflow-hidden rounded-lg">
      {!capturedImage ? (
        <div className="relative">
          <Webcam
            audio={false}
            ref={webcamRef}
            screenshotFormat="image/jpeg"
            videoConstraints={videoConstraints}
            className="w-full rounded-lg"
            height={480}
            width={720}
          />
          <div className="absolute bottom-4 left-0 right-0 flex justify-center">
            <Button
              onClick={capture}
              size="lg"
              className="rounded-full h-14 w-14 p-0 shadow-lg"
            >
              <Camera className="h-6 w-6" />
            </Button>
          </div>
        </div>
      ) : (
        <div className="relative">
          <img
            src={capturedImage}
            alt="Captured pollution"
            className="w-full rounded-lg"
          />
          <div className="absolute bottom-4 left-0 right-0 flex justify-center space-x-4">
            <Button
              onClick={retake}
              variant="outline"
              size="sm"
              className="bg-background/80 backdrop-blur-sm"
            >
              <RefreshCw className="mr-2 h-4 w-4" />
              Retake
            </Button>
            <Button
              onClick={confirmImage}
              size="sm"
              className="bg-primary/90 backdrop-blur-sm"
            >
              <Check className="mr-2 h-4 w-4" />
              Use Photo
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
