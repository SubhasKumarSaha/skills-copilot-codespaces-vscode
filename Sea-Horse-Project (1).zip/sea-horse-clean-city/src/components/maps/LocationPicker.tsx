"use client";

import { useEffect, useState } from 'react';
import { MapPin, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { GeoLocation } from '@/types';
import { getCurrentLocation, getAddressFromCoords } from '@/utils/geolocation';

interface LocationPickerProps {
  onLocationSelect: (location: { latitude: number; longitude: number; address?: string }) => void;
}

export function LocationPicker({ onLocationSelect }: LocationPickerProps) {
  const [location, setLocation] = useState<GeoLocation | null>(null);
  const [address, setAddress] = useState<string | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const detectLocation = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const currentLocation = await getCurrentLocation();
      setLocation(currentLocation);

      // Get address from coordinates
      if (!currentLocation.error) {
        const addressResult = await getAddressFromCoords(
          currentLocation.latitude,
          currentLocation.longitude
        );
        setAddress(addressResult);

        // Pass location to parent component
        onLocationSelect({
          latitude: currentLocation.latitude,
          longitude: currentLocation.longitude,
          address: addressResult
        });
      } else {
        setError(currentLocation.error);
      }
    } catch (err) {
      setError('Failed to detect location. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    // Auto-detect location when component mounts
    detectLocation();
  }, []);

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Location</h3>
        <Button
          variant="outline"
          size="sm"
          onClick={detectLocation}
          disabled={isLoading}
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Detecting...
            </>
          ) : (
            <>
              <MapPin className="mr-2 h-4 w-4" />
              Detect Location
            </>
          )}
        </Button>
      </div>

      {error && (
        <div className="text-sm text-red-500 mb-2">
          {error}
        </div>
      )}

      {location && !location.error && (
        <Card className="overflow-hidden">
          <div className="p-4 flex items-start">
            <div className="bg-primary/10 p-2 rounded-full mr-4">
              <MapPin className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="font-medium">{address || 'Location detected'}</p>
              <p className="text-sm text-muted-foreground">
                Lat: {location.latitude.toFixed(6)}, Lng: {location.longitude.toFixed(6)}
              </p>
            </div>
          </div>
        </Card>
      )}

      <div className="text-sm text-muted-foreground">
        Your precise location helps authorities find and address the pollution issue more efficiently.
      </div>
    </div>
  );
}
