"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { MapPin, Camera, Upload } from "lucide-react";
import { CameraCapture } from "@/components/upload/CameraCapture";
import { LocationPicker } from "@/components/maps/LocationPicker";

// Define form validation schema
const formSchema = z.object({
  title: z.string().min(5, "Title must be at least 5 characters").max(100, "Title cannot exceed 100 characters"),
  description: z.string().min(20, "Description must be at least 20 characters").max(500, "Description cannot exceed 500 characters"),
  imageUrl: z.string().min(1, "Please capture or upload an image of the pollution"),
  location: z.object({
    latitude: z.number(),
    longitude: z.number(),
    address: z.string().optional(),
  }),
});

export default function UploadPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Initialize form
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      imageUrl: "",
      location: {
        latitude: 0,
        longitude: 0,
      },
    },
  });

  // Handle image capture from camera component
  const handleImageCapture = (imageSrc: string) => {
    setCapturedImage(imageSrc);
    form.setValue("imageUrl", imageSrc);
  };

  // Handle location selection
  const handleLocationSelect = (location: { latitude: number; longitude: number; address?: string }) => {
    form.setValue("location", location);
  };

  // Handle form submission
  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    setIsSubmitting(true);

    try {
      // In a real app, this would be an API call to save the report
      console.log("Report data:", values);

      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Show success message
      toast({
        title: "Report submitted successfully",
        description: "Your pollution report has been sent to local authorities.",
        variant: "default",
      });

      // Redirect to dashboard
      router.push("/dashboard");
    } catch (error) {
      console.error("Error submitting report:", error);

      toast({
        title: "Failed to submit report",
        description: "There was an error submitting your report. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="container py-10">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold mb-2">Report Pollution</h1>
        <p className="text-muted-foreground mb-8">
          Help keep your city clean by reporting pollution. Your report will be sent to local authorities.
        </p>

        <Card>
          <CardContent className="pt-6">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                {/* Title field */}
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input placeholder="E.g., Plastic waste on beach" {...field} />
                      </FormControl>
                      <FormDescription>
                        A clear, concise title describing the pollution issue
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Description field */}
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Describe the pollution in detail, including any relevant information about severity and extent..."
                          className="min-h-32"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>
                        Provide a detailed description to help authorities assess the situation
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Location picker */}
                <div className="space-y-4">
                  <LocationPicker onLocationSelect={handleLocationSelect} />
                </div>

                {/* Image capture */}
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Photo Evidence</h3>
                  <FormField
                    control={form.control}
                    name="imageUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <div className="hidden">{field.value}</div>
                        </FormControl>
                        <CameraCapture onCapture={handleImageCapture} />
                        <FormDescription>
                          Take a clear photo of the pollution to help authorities identify and address the issue
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {capturedImage && (
                    <div className="py-2">
                      <p className="text-sm text-green-600 dark:text-green-400 flex items-center">
                        <Camera className="h-4 w-4 mr-2" />
                        Image captured successfully
                      </p>
                    </div>
                  )}
                </div>

                {/* Submit button */}
                <Button type="submit" className="w-full" disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <Upload className="mr-2 h-4 w-4 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    "Submit Report"
                  )}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
