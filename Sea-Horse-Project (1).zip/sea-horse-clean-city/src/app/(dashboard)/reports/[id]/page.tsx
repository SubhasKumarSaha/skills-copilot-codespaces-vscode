"use client";

import { useState } from 'react';
import { useParams, notFound } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Calendar, Clock, ArrowLeft, User, Check, X, Upload, UploadCloud } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { dummyReports } from '@/utils/dummy-data';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';

export default function ReportDetail() {
  const params = useParams();
  const id = params?.id as string;
  const report = dummyReports.find(r => r.id === id);

  const [showAuthReportDialog, setShowAuthReportDialog] = useState(false);

  if (!report) {
    notFound();
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'in-progress': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'completed': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
    }
  };

  const getStatusIcon = (status: string) => {
    switch(status) {
      case 'pending': return <Clock className="h-4 w-4 mr-2" />;
      case 'in-progress': return <Upload className="h-4 w-4 mr-2" />;
      case 'completed': return <Check className="h-4 w-4 mr-2" />;
      default: return null;
    }
  };

  return (
    <div className="container py-10">
      <Link
        href="/reports"
        className="inline-flex items-center text-sm text-muted-foreground mb-6 hover:text-foreground transition-colors"
      >
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to reports
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
            <div>
              <h1 className="text-3xl font-bold mb-2">{report.title}</h1>
              <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 mr-1" />
                  {report.location.address}
                </div>
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-1" />
                  {formatDate(report.createdAt)}
                </div>
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-1" />
                  {formatTime(report.createdAt)}
                </div>
              </div>
            </div>
            <Badge
              variant="outline"
              className={`${getStatusColor(report.status)} text-sm px-3 py-1 flex items-center`}
            >
              {getStatusIcon(report.status)}
              {report.status.charAt(0).toUpperCase() + report.status.slice(1).replace('-', ' ')}
            </Badge>
          </div>

          <Tabs defaultValue="details" className="mb-8">
            <TabsList className="mb-4">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="progress" disabled={report.status === 'pending'}>
                Cleanup Progress
              </TabsTrigger>
            </TabsList>

            <TabsContent value="details">
              <Card className="overflow-hidden mb-6">
                <div className="relative h-[300px] md:h-[400px]">
                  <Image
                    src={report.imageUrl}
                    alt={report.title}
                    fill
                    className="object-cover"
                  />
                </div>
                <CardContent className="p-6">
                  <h3 className="font-semibold text-lg mb-2">Description</h3>
                  <p className="text-muted-foreground mb-4">
                    {report.description}
                  </p>

                  {report.status === 'pending' && (
                    <Alert className="bg-yellow-100 text-yellow-800 border-yellow-400 dark:bg-yellow-900/20 dark:border-yellow-800 dark:text-yellow-300">
                      <AlertDescription className="flex items-center text-sm">
                        <Clock className="h-4 w-4 mr-2" />
                        This report is awaiting assignment to a municipal team for cleanup.
                      </AlertDescription>
                    </Alert>
                  )}

                  {report.status === 'in-progress' && (
                    <Alert className="bg-blue-100 text-blue-800 border-blue-400 dark:bg-blue-900/20 dark:border-blue-800 dark:text-blue-300">
                      <AlertDescription className="flex items-center text-sm">
                        <Upload className="h-4 w-4 mr-2" />
                        This report has been assigned and is currently being addressed.
                      </AlertDescription>
                    </Alert>
                  )}

                  {report.status === 'completed' && (
                    <Alert className="bg-green-100 text-green-800 border-green-400 dark:bg-green-900/20 dark:border-green-800 dark:text-green-300">
                      <AlertDescription className="flex items-center text-sm">
                        <Check className="h-4 w-4 mr-2" />
                        This pollution issue has been successfully cleaned up.
                      </AlertDescription>
                    </Alert>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="progress">
              {report.status === 'in-progress' && (
                <Card className="overflow-hidden mb-6">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold text-lg">Cleanup In Progress</h3>
                      <Badge variant="outline" className="bg-blue-100 text-blue-800 border-0">
                        Assigned
                      </Badge>
                    </div>
                    <p className="text-muted-foreground mb-6">
                      This pollution report has been assigned to the municipal waste management team and is scheduled for cleanup.
                    </p>
                    <div className="flex items-center text-sm text-muted-foreground mb-1">
                      <User className="h-4 w-4 mr-2" />
                      <span>Assigned to: Municipal Waste Management Team</span>
                    </div>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Calendar className="h-4 w-4 mr-2" />
                      <span>Assigned on: {formatDate(report.updatedAt)}</span>
                    </div>
                  </CardContent>
                </Card>
              )}

              {report.status === 'completed' && report.cleanupImageUrl && (
                <Card className="overflow-hidden mb-6">
                  <div className="relative h-[300px] md:h-[400px]">
                    <Image
                      src={report.cleanupImageUrl}
                      alt="Cleaned up area"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold text-lg">Cleanup Completed</h3>
                      <Badge variant="outline" className="bg-green-100 text-green-800 border-0">
                        Complete
                      </Badge>
                    </div>
                    <p className="text-muted-foreground mb-6">
                      The area has been successfully cleaned up by the municipal team.
                    </p>
                    <div className="flex items-center text-sm text-muted-foreground mb-1">
                      <User className="h-4 w-4 mr-2" />
                      <span>Completed by: Municipal Waste Management Team</span>
                    </div>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Calendar className="h-4 w-4 mr-2" />
                      <span>Completed on: {formatDate(report.updatedAt)}</span>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>

        <div>
          <Card className="mb-6">
            <CardContent className="p-6">
              <h3 className="font-semibold text-lg mb-4">Authority Actions</h3>

              {report.status === 'pending' && (
                <>
                  <p className="text-muted-foreground mb-4">
                    This pollution report needs to be assigned to a municipal team for cleanup.
                  </p>
                  <Button className="w-full">
                    Mark as In Progress
                  </Button>
                </>
              )}

              {report.status === 'in-progress' && (
                <>
                  <p className="text-muted-foreground mb-4">
                    Upload photo evidence of the completed cleanup to mark this report as resolved.
                  </p>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button className="w-full">
                        <UploadCloud className="mr-2 h-4 w-4" />
                        Upload Cleanup Photo
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Upload Cleanup Evidence</DialogTitle>
                        <DialogDescription>
                          Upload a photo showing the area has been cleaned up.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="py-4">
                        <p className="text-center text-muted-foreground mb-4">
                          This is a demo mockup. In a real application, this would allow authority users to upload photos.
                        </p>
                        <Button className="w-full">
                          Mark as Completed
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </>
              )}

              {report.status === 'completed' && (
                <>
                  <div className="flex flex-col items-center justify-center py-4 text-center">
                    <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mb-4">
                      <Check className="h-8 w-8 text-green-600" />
                    </div>
                    <p className="font-medium">Cleanup Completed</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      This issue has been successfully resolved
                    </p>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h3 className="font-semibold text-lg mb-4">Report Information</h3>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Report ID</p>
                  <p className="font-medium">{report.id}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Reporter</p>
                  <p className="font-medium">John Citizen</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Location Coordinates</p>
                  <p className="font-medium">{report.location.latitude}, {report.location.longitude}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Reported On</p>
                  <p className="font-medium">{formatDate(report.createdAt)} at {formatTime(report.createdAt)}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Last Updated</p>
                  <p className="font-medium">{formatDate(report.updatedAt)} at {formatTime(report.updatedAt)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
