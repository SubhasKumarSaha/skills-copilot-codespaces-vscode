"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { dummyReports } from "@/utils/dummy-data";
import { MapPin, Clock, Search, Filter } from "lucide-react";
import { Input } from "@/components/ui/input";

type StatusFilter = 'all' | 'pending' | 'in-progress' | 'completed';

export default function ReportsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');

  const filteredReports = dummyReports
    .filter(report =>
      report.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      report.description.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .filter(report => statusFilter === 'all' ? true : report.status === statusFilter);

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'in-progress': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'completed': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-2">Pollution Reports</h1>
      <p className="text-muted-foreground mb-8">
        Browse through all submitted pollution reports and track their status
      </p>

      {/* Search and Filter */}
      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search reports..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <Button
            variant={statusFilter === 'all' ? 'default' : 'outline'}
            onClick={() => setStatusFilter('all')}
            className="px-4"
          >
            All
          </Button>
          <Button
            variant={statusFilter === 'pending' ? 'default' : 'outline'}
            onClick={() => setStatusFilter('pending')}
            className="px-4"
          >
            Pending
          </Button>
          <Button
            variant={statusFilter === 'in-progress' ? 'default' : 'outline'}
            onClick={() => setStatusFilter('in-progress')}
            className="px-4"
          >
            In Progress
          </Button>
          <Button
            variant={statusFilter === 'completed' ? 'default' : 'outline'}
            onClick={() => setStatusFilter('completed')}
            className="px-4"
          >
            Completed
          </Button>
        </div>
      </div>

      {/* Reports Grid */}
      {filteredReports.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredReports.map((report) => (
            <Card key={report.id} className="overflow-hidden flex flex-col">
              <div className="relative h-48">
                <Image
                  src={report.imageUrl}
                  alt={report.title}
                  fill
                  className="object-cover"
                />
                <div className="absolute top-2 right-2">
                  <Badge
                    variant="outline"
                    className={`${getStatusColor(report.status)} border-0`}
                  >
                    {report.status.charAt(0).toUpperCase() + report.status.slice(1).replace('-', ' ')}
                  </Badge>
                </div>
              </div>
              <CardContent className="p-5 flex-1">
                <h3 className="font-semibold text-lg mb-2 line-clamp-1">{report.title}</h3>
                <p className="text-muted-foreground text-sm mb-3 line-clamp-2">
                  {report.description}
                </p>
                <div className="flex items-center text-sm text-muted-foreground mb-1">
                  <MapPin className="h-3 w-3 mr-2" />
                  <span className="line-clamp-1">{report.location.address}</span>
                </div>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Clock className="h-3 w-3 mr-2" />
                  <span>Reported on {formatDate(report.createdAt)}</span>
                </div>
              </CardContent>
              <CardFooter className="p-5 pt-0">
                <Button variant="outline" asChild className="w-full">
                  <Link href={`/reports/${report.id}`}>View Details</Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <div className="mb-4 text-muted-foreground">
            <Filter className="h-12 w-12 mx-auto" />
          </div>
          <h3 className="text-lg font-medium mb-2">No reports found</h3>
          <p className="text-muted-foreground mb-4">
            No pollution reports match your current search criteria.
          </p>
          <Button onClick={() => {setSearchTerm(''); setStatusFilter('all');}}>
            Clear Filters
          </Button>
        </div>
      )}
    </div>
  );
}
