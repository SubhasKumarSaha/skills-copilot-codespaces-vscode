"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { dummyReports } from "@/utils/dummy-data";
import { MapPin, Clock, AlertTriangle, CheckCircle, ArrowUpRight } from "lucide-react";

type StatusFilter = 'all' | 'pending' | 'in-progress' | 'completed';

export default function DashboardPage() {
  const [filter, setFilter] = useState<StatusFilter>('all');

  const totalReports = dummyReports.length;
  const pendingReports = dummyReports.filter(report => report.status === 'pending').length;
  const inProgressReports = dummyReports.filter(report => report.status === 'in-progress').length;
  const completedReports = dummyReports.filter(report => report.status === 'completed').length;

  const filteredReports = filter === 'all'
    ? dummyReports
    : dummyReports.filter(report => report.status === filter);

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'in-progress': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'completed': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
      <p className="text-muted-foreground mb-8">
        Monitor pollution reports and cleanup progress across the city
      </p>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Reports</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{totalReports}</div>
            <p className="text-xs text-muted-foreground mt-1">Reports submitted</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Pending</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-yellow-500">{pendingReports}</div>
            <p className="text-xs text-muted-foreground mt-1">Awaiting action</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">In Progress</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-500">{inProgressReports}</div>
            <p className="text-xs text-muted-foreground mt-1">Being addressed</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Completed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-500">{completedReports}</div>
            <p className="text-xs text-muted-foreground mt-1">Successfully resolved</p>
          </CardContent>
        </Card>
      </div>

      {/* Reports Table */}
      <div className="bg-background border rounded-lg overflow-hidden mb-8">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="font-semibold">Recent Reports</h2>
          <Tabs defaultValue="all" className="w-[400px]" onValueChange={(value) => setFilter(value as StatusFilter)}>
            <TabsList className="grid grid-cols-4">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="pending">Pending</TabsTrigger>
              <TabsTrigger value="in-progress">In Progress</TabsTrigger>
              <TabsTrigger value="completed">Completed</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b bg-muted/40">
                <th className="px-4 py-3 text-left text-sm font-medium">Title</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Location</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Date</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Status</th>
                <th className="px-4 py-3 text-right text-sm font-medium">Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredReports.map((report) => (
                <tr key={report.id} className="border-b">
                  <td className="px-4 py-3 text-sm">{report.title}</td>
                  <td className="px-4 py-3 text-sm text-muted-foreground">
                    <div className="flex items-center">
                      <MapPin className="h-3 w-3 mr-1" />
                      {report.location.address}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm text-muted-foreground">
                    <div className="flex items-center">
                      <Clock className="h-3 w-3 mr-1" />
                      {formatDate(report.createdAt)}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm">
                    <Badge variant="outline" className={getStatusColor(report.status)}>
                      {report.status === 'pending' && <AlertTriangle className="h-3 w-3 mr-1" />}
                      {report.status === 'in-progress' && <Clock className="h-3 w-3 mr-1" />}
                      {report.status === 'completed' && <CheckCircle className="h-3 w-3 mr-1" />}
                      {report.status.charAt(0).toUpperCase() + report.status.slice(1).replace('-', ' ')}
                    </Badge>
                  </td>
                  <td className="px-4 py-3 text-sm text-right">
                    <Button variant="ghost" size="sm" asChild>
                      <Link href={`/reports/${report.id}`}>
                        View <ArrowUpRight className="ml-1 h-3 w-3" />
                      </Link>
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Call to Action */}
      <Card className="bg-primary/5 border-primary/20">
        <CardContent className="p-6">
          <div className="grid gap-4 md:grid-cols-2 items-center">
            <div>
              <h3 className="text-xl font-semibold mb-2">Report a New Pollution Issue</h3>
              <p className="text-muted-foreground">
                Help keep our city clean by reporting pollution. Your contribution makes a difference.
              </p>
            </div>
            <div className="flex justify-end">
              <Button asChild>
                <Link href="/upload">Report Now</Link>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
