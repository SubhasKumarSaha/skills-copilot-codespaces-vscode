import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { AlertTriangle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="container flex flex-col items-center justify-center py-20 text-center">
      <div className="relative w-40 h-40 mb-8">
        <Image
          src="/images/seahorse-logo.png"
          alt="Sea Horse Logo"
          fill
          className="object-contain opacity-40"
        />
      </div>
      <AlertTriangle className="h-16 w-16 text-primary/40 mb-4" />
      <h1 className="text-4xl font-bold mb-4">Page Not Found</h1>
      <p className="text-muted-foreground max-w-md mb-8">
        We couldn't find the page you're looking for. The page might have been removed, renamed,
        or is temporarily unavailable.
      </p>
      <div className="flex flex-col sm:flex-row gap-4">
        <Button asChild size="lg">
          <Link href="/">Return Home</Link>
        </Button>
        <Button variant="outline" asChild size="lg">
          <Link href="/dashboard">Go to Dashboard</Link>
        </Button>
      </div>
    </div>
  );
}
