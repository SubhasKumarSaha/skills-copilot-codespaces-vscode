import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight, Leaf, MapPin, BarChart3, Upload } from "lucide-react";

export default function Home() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative py-20 md:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-primary/5 -z-10"></div>
        <div className="absolute inset-0 bg-[url('/images/dashboard-bg.jpg')] bg-cover bg-center opacity-10 -z-20"></div>
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="space-y-4">
              <div className="inline-block rounded-lg bg-primary/10 px-3 py-1 text-sm text-primary-foreground mb-2">
                AI-Powered Clean City Platform
              </div>
              <h1 className="text-3xl md:text-5xl font-bold tracking-tighter">
                Report Pollution. Track Cleanup. Save Our Cities.
              </h1>
              <p className="text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Sea Horse uses AI to analyze and categorize pollution, connecting citizens with local authorities for faster cleanups.
              </p>
              <div className="flex flex-col md:flex-row gap-3 pt-4">
                <Button asChild size="lg">
                  <Link href="/upload">Report Pollution</Link>
                </Button>
                <Button variant="outline" asChild size="lg">
                  <Link href="/dashboard">View Dashboard</Link>
                </Button>
              </div>
            </div>
            <div className="relative h-[300px] md:h-[400px] rounded-xl overflow-hidden">
              <Image
                src="/images/seahorse-real.jpg"
                alt="Seahorse in ocean"
                fill
                className="object-cover rounded-xl"
                priority
              />
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-12 md:py-24 bg-muted/50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">How It Works</h2>
            <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed">
              Our platform connects citizens, AI technology, and municipal authorities for efficient pollution management.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="border-border/40">
              <CardHeader className="pb-3">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-3">
                  <Upload className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>Upload & Analyze</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Capture a photo of pollution, and our AI will analyze the type and severity. Your location is automatically recorded.
                </p>
              </CardContent>
            </Card>
            <Card className="border-border/40">
              <CardHeader className="pb-3">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-3">
                  <MapPin className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>Alert Authorities</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Your report is sent to local municipal organizations responsible for the affected area with detailed information.
                </p>
              </CardContent>
            </Card>
            <Card className="border-border/40">
              <CardHeader className="pb-3">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-3">
                  <Leaf className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>Track Cleanup</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Authorities document the cleanup with photos. You can track progress from report to resolution in real-time.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 md:py-24">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="space-y-4">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Making a Measurable Impact</h2>
              <p className="text-muted-foreground md:text-xl">
                Our AI-powered platform is helping communities transform their environments through data-driven action.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center">
                  <ArrowRight className="mr-2 h-4 w-4 text-primary" />
                  <span>90% faster response time from authorities</span>
                </li>
                <li className="flex items-center">
                  <ArrowRight className="mr-2 h-4 w-4 text-primary" />
                  <span>Accurately identifies 12+ types of pollution</span>
                </li>
                <li className="flex items-center">
                  <ArrowRight className="mr-2 h-4 w-4 text-primary" />
                  <span>GPS location tracking within 5 meter accuracy</span>
                </li>
              </ul>
              <Button className="mt-4" asChild>
                <Link href="/reports">View Success Stories</Link>
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Card className="border-border/40">
                <CardHeader className="pb-2">
                  <CardTitle className="text-4xl font-bold text-primary">500+</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">Pollution reports submitted</p>
                </CardContent>
              </Card>
              <Card className="border-border/40">
                <CardHeader className="pb-2">
                  <CardTitle className="text-4xl font-bold text-primary">87%</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">Issues successfully resolved</p>
                </CardContent>
              </Card>
              <Card className="border-border/40">
                <CardHeader className="pb-2">
                  <CardTitle className="text-4xl font-bold text-primary">15</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">Municipal organizations</p>
                </CardContent>
              </Card>
              <Card className="border-border/40">
                <CardHeader className="pb-2">
                  <CardTitle className="text-4xl font-bold text-primary">7</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">Days average resolution time</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 md:py-24 bg-primary/5">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Join the Clean City Movement</h2>
            <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed">
              Be part of the solution. Report pollution in your area and help create cleaner, healthier cities for everyone.
            </p>
            <div className="flex flex-col md:flex-row gap-4 pt-4">
              <Button asChild size="lg">
                <Link href="/upload">Report Pollution Now</Link>
              </Button>
              <Button variant="outline" asChild size="lg">
                <Link href="/dashboard">View Our Impact</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
