import Image from "next/image";
import { Loader2 } from "lucide-react";

export default function Loading() {
  return (
    <div className="container flex flex-col items-center justify-center min-h-[70vh]">
      <div className="relative w-24 h-24 mb-4">
        <Image
          src="/images/green-seahorse-logo.jpg"
          alt="Sea Horse Logo"
          fill
          className="object-contain"
        />
      </div>
      <div className="flex items-center gap-2 text-primary">
        <Loader2 className="h-6 w-6 animate-spin" />
        <p className="text-lg font-medium">Loading...</p>
      </div>
    </div>
  );
}
